package model;

public abstract class AbstractSaudacaoFabrica {
		
	public abstract Usuario getUsuario(String nome);
}
