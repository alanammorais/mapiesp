package model;

public abstract class DrawAPI { // pode ser uma interface
	
	public abstract String drawCircle(int radius, int x, int y);
}
