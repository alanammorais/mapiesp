package model;

public interface JanelaImplementada { //pode ser abstrata ou concreta

	public String desenharJanela(String titulo);
	 
    public String desenharBotao(String titulo);
	
}
