package model;

public abstract class JanelaAbstrata { 
	private JanelaImplementada janela;
	 
    public JanelaAbstrata(JanelaImplementada j) {
        janela = j;
    }
 
    public String desenharJanela(String titulo) {
        return janela.desenharJanela(titulo);
    }
 
    public String desenharBotao(String titulo) {
        return janela.desenharBotao(titulo);
    }
 
    public abstract void desenhar();
}
