package aulaExemploFM.modelo;

public abstract class AbstractFactoryShape {
	
	public abstract Shape getShape(String tipo);

}
