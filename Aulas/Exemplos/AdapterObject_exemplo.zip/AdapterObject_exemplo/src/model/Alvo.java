package model;

public abstract class Alvo {
	public abstract void operacao();
	
	//Outras Operações
}
