package view;
import model.Adaptador;
import model.Alvo;

public class Cliente {
	static Alvo[] alvos = new Alvo[3];
	
	public static void inicializaAlvos() {
		for(int i = 0; i < alvos.length; i++) {
			alvos[i]= new Adaptador();
		}
	
	}
	public static void executaAlvos() {
		for(int i = 0; i < alvos.length; i++) {
				alvos[i].operacao();
		}
	}
	
	public static void main(String[] args) {
		
		inicializaAlvos();
		executaAlvos();
		
	}
	
	
}




