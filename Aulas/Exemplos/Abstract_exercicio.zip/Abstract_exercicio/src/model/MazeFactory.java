package model;

import model.elementos.Door;
import model.elementos.EnchantedDoor;
import model.elementos.EnchantedRoom;
import model.elementos.Environment;
import model.elementos.Room;

public class MazeFactory extends AbstractMazeFactory{
		
	public MazeFactory() {
		this.env = new Environment();
	}
	
	public Environment getInstance(){
		makeRoom();
		makeDoor();
		makeMaze();
		makeWall();
		return this.env;
	}

	public void makeRoom() {
		this.env.setSala(new Room());
	}

	public void makeDoor() {
		this.env.setPorta(new Door());
	}
	
	public void makeMaze() {
		System.out.println("Constroi labirinto");
	}

	public void makeWall() {
		System.out.println("Constroi muro");
	}

}
