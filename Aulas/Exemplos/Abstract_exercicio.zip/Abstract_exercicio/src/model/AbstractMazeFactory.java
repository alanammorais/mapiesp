package model;

import model.elementos.Environment;

public abstract class AbstractMazeFactory {
	
	protected Environment env;
	
	public AbstractMazeFactory(){}
	
	public abstract void makeRoom();
	
	public abstract void makeMaze();
	
	public abstract void makeWall();
	
	public abstract void makeDoor();
	
	public abstract Environment getInstance();
}
