package model.elementos;

public class AbstractDoor {
	
	public AbstractDoor() {}
}
