package model.elementos;

public class Door extends AbstractDoor{
	
	public Door(){
		System.out.println("Door");
	}


}
