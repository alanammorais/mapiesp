package model.elementos;

public class Environment {
	
	private AbstractRoom sala;
	private AbstractDoor porta;
	//private AbstractMaze labirinto;
	//private AbstractWall muro;
	
	public Environment() {}
	
	public Environment(AbstractRoom sala, AbstractDoor porta) {
		this.sala = sala;
		this.porta = porta;
	}

	public AbstractRoom getSala() {
		return sala;
	}

	public void setSala(AbstractRoom sala) {
		this.sala = sala;
	}

	public AbstractDoor getPorta() {
		return porta;
	}

	public void setPorta(AbstractDoor porta) {
		this.porta = porta;
	}
	

}
