package model.elementos;

public class Room extends AbstractRoom{
	
	public Room(){
		System.out.println("Room");
	}

}
