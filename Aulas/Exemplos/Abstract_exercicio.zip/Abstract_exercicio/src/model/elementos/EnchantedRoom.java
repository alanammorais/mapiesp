package model.elementos;

public class EnchantedRoom extends AbstractRoom{

	public EnchantedRoom(){
		System.out.println("Enchanted Room");
	}
}

