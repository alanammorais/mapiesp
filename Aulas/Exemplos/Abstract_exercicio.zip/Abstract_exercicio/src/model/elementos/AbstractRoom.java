package model.elementos;


public class AbstractRoom {
	
	public AbstractRoom() {}

}
