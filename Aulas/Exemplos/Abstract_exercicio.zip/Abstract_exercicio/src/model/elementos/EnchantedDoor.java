package model.elementos;

public class EnchantedDoor extends AbstractDoor{
	
	public EnchantedDoor(){
		System.out.println("Enchanted Door");
	}

}
