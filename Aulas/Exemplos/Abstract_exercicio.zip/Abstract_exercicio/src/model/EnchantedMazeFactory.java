package model;

import model.elementos.EnchantedDoor;
import model.elementos.EnchantedRoom;
import model.elementos.Environment;

public class EnchantedMazeFactory extends AbstractMazeFactory{
	
	public EnchantedMazeFactory() {
		this.env = new Environment();
	}
	
	public Environment getInstance(){
		makeRoom();
		makeDoor();
		makeMaze();
		makeWall();
		return this.env;
	}
	
	public void makeRoom() {
		this.env.setSala(new EnchantedRoom());
	}

	public void makeDoor() {
		this.env.setPorta(new EnchantedDoor());
	}

	public void makeMaze() {
		System.out.println("Constroi labirinto encantado");		
	}

	public void makeWall() {
		System.out.println("Constroi muro encantado");
		
	}

	
	
	
}
