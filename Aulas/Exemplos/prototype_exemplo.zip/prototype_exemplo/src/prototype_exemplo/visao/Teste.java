package prototype_exemplo.visao;

import prototype_exemplo.model.CarroPrototype;
import prototype_exemplo.model.PalioPrototype;

public class Teste {
	public static void main(String[] args) {
	    PalioPrototype prototipoPalio = new PalioPrototype();
	    prototipoPalio.setValorCompra(15000);
	    System.out.println(prototipoPalio.getValorCompra());
	 
	    
	    CarroPrototype palioNovo = prototipoPalio.clonar();
	    System.out.println(palioNovo.getValorCompra());
	    palioNovo.setValorCompra(27900.0);
	    System.out.println(palioNovo.getValorCompra());
	    
	    CarroPrototype palioUsado = prototipoPalio.clonar();
	    palioUsado.setValorCompra(11000.0);
	    
	    System.out.println("\n\n");
	    System.out.println(palioNovo.exibirInfo());
	    System.out.println(palioUsado.exibirInfo());
	    System.out.println(prototipoPalio.exibirInfo());
	}
}
