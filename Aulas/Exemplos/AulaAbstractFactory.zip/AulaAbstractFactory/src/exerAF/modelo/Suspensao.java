package exerAF.modelo;

public class Suspensao {

}
