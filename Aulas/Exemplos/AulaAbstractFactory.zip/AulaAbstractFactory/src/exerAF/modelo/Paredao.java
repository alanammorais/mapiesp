package exerAF.modelo;

public class Paredao extends Som{

	public Paredao(){
		System.out.println("Construiu Paredao");
	}
}
