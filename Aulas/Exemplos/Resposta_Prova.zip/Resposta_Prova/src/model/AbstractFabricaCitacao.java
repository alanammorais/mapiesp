package model;

public abstract class AbstractFabricaCitacao {
	
	public abstract Nome getNome();

}
