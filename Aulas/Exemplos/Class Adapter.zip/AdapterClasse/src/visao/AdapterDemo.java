package visao;

import controlador.Cliente;
import modelo.Adaptador;
import modelo.Alvo;

public class AdapterDemo {
	
	public static void main(String[] args) {
		Cliente c = new Cliente();
		c.inicializaAlvos();
		c.executaAlvos();
		
	    Alvo contrato = new Adaptador();
		contrato.operacao();
	    
	   }
}
