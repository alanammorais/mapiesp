package singleton_exemplo.model;


public class SingletonObject {
	   //Atributo de mim mesma como atributo
	   private static SingletonObject instance = new SingletonObject();
	   
	   //Construtor nunca será público
	   private SingletonObject(){
		  System.out.println("Construtor Classe"); 
	   }

	   //Implementar metodo getInstance
	   public static SingletonObject getInstance(){
	      return instance;
	   }

	   public void showMessage(){
	      System.out.println("Hello World!");
	   }
}
