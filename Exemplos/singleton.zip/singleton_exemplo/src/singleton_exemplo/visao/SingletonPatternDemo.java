package singleton_exemplo.visao;

import singleton_exemplo.model.SingletonObject;

public class SingletonPatternDemo {
	
	public static void main(String[] args) {

	      SingletonObject object = SingletonObject.getInstance();
	      SingletonObject object2 = SingletonObject.getInstance();
	      
	      //show the message
	      object.showMessage();
	      object2.showMessage();
	   }
}
