package model;

public class LoggerSingleton {
	
	private static LoggerSingleton lg;
	
	private LoggerSingleton(){
		System.out.println("Passando pelo construtor");
	}
	
	public static LoggerSingleton getInstance() {
        if (lg == null) {
            lg = new LoggerSingleton(); // o objeto pode ser instanciado no construtor
        }
        return lg;
    }

	public void registrarLog(String dados) {
        System.out.println("Vou registrar o log: " + dados);
    }
}
