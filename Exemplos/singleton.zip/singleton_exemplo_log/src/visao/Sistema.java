package visao;

import model.LoggerSingleton;

public class Sistema {
	public static void main(String[] args) {
		// vamos registrar um novo log usando a classe Singleton
		LoggerSingleton.getInstance().registrarLog("Novo usuário cadastrado.");
		LoggerSingleton.getInstance().registrarLog("Usuário logado.");
	}


}
