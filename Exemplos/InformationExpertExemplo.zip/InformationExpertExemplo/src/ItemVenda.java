
public class ItemVenda {
	private int quantidade;
	private EspecificacaoProduto esp;
	
	public ItemVenda() {}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public EspecificacaoProduto getEsp() {
		return esp;
	}

	public void setEsp(EspecificacaoProduto esp) {
		this.esp = esp;
	}
	
	
	
	
	
}
