
public class EspecificacaoProduto {
	private String texto;
	private double preco;
	
	public EspecificacaoProduto(String texto, double preco) {
		this.texto = texto;
		this.preco = preco;
	}
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	
}
