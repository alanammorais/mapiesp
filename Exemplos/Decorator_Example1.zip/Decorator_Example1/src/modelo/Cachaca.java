package modelo;

public class Cachaca extends Coquetel {
    
	public Cachaca() {
        super.setNome("Cachaça");
        super.setPreco(3);
    }
}