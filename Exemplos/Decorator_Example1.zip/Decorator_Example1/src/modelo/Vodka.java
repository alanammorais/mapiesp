package modelo;

public class Vodka extends Coquetel{

	public Vodka() {
		super.setNome("Vodka");
		super.setPreco(8);
	}

}
