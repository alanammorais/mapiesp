package modelo;

public class Suco extends CoquetelDecorator {

	public Suco(Coquetel umCoquetel) {
		super(umCoquetel);
        super.setNome("Refrigerante");
        super.setPreco(3);
	}

}
