package modelo;

public class Rum extends Coquetel{

	public Rum() {
		super.setNome("Rum");
        super.setPreco(5);
	}

}
