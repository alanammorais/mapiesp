package model;
public class Produto {

	public static Produto create(String nome, int id, double preco) {
		System.out.println("Cria Produto");
		return null;
	}

}