package model;
public class Cliente {
	public static Cliente create(String nome, int id) {
		return null;
	}
	
	public void adicionarCarrinho(Carrinho c) {
		System.out.println("Adicionar Carrinho");
	}
	
	public Carrinho getCarrinho() {
		return null;
	}

}

