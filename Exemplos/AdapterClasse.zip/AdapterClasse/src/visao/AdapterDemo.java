package visao;

import modelo.Adaptador;
import modelo.Alvo;

public class AdapterDemo {
	
	public static void main(String[] args) {
	    Alvo contrato = new Adaptador();
		contrato.operacao();
	    
	   }
}
