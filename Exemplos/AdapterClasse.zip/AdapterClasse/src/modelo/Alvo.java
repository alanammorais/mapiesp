package modelo;

public interface Alvo {
	
	public void operacao();
}
