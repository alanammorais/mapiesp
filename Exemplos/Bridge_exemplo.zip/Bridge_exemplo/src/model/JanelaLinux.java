package model;

public class JanelaLinux implements JanelaImplementada{
	
	public JanelaLinux() {}

	public String desenharJanela(String titulo) {
		return (titulo + " - Janela Linux");
		
	}

	public String desenharBotao(String titulo) {
		return (titulo + " - Botao Linux");
		
	}

}
