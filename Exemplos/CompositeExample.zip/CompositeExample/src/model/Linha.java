package model;

public class Linha extends Grafico{
	
	public Linha() {
		super();
	}

	public void desenhar() {
		System.out.println("Desenha Linha");
		
	}

}
