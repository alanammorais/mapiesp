package model;

public class Texto extends Grafico{
	
	public Texto() {
		super();
	}

	public void desenhar() {
		System.out.println("Escreve Texto");
		
	}



}
