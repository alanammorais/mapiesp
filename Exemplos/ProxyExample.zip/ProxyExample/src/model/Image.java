package model;
public interface Image {
	
	void display();
}
