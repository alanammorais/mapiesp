package modelo;

public abstract class Construtor {
	
	public Construtor() {}
		
	public abstract void passoUm();
	public abstract void passoDois();
	public abstract Object obterProduto();
	
}
