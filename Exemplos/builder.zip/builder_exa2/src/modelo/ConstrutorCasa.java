package modelo;

public class ConstrutorCasa extends Construtor{
	
	private Casa casa;
	
	public ConstrutorCasa(Casa casa) {
		this.casa = casa;
	}

	public void passoUm() {
		// Informacoes e calculos complexos
		System.out.println("Passo UM Casa");
		
	}

	public void passoDois() {
		// Informacoes e calculos complexos
		System.out.println("Passo DOIS Casa");
		
	}

	public Object obterProduto() {
		return this.casa;
	}


}
