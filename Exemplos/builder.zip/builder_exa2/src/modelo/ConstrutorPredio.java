package modelo;

public class ConstrutorPredio extends Construtor{

	private Predio predio;
	
	public ConstrutorPredio(Predio predio) {
		this.predio = predio;
	}

	public void passoUm() {
		// Informacoes e calculos complexos
		System.out.println("Passo UM Predio");
		
	}

	public void passoDois() {
		// Informacoes e calculos complexos
		System.out.println("Passo DOIS Predio");
		
	}

	public Object obterProduto() {
		return this.predio;
	}

	

}
