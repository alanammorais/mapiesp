package main;

import modelo.Casa;
import modelo.ConstrutorCasa;
import modelo.ConstrutorPredio;
import modelo.Diretor;
import modelo.Predio;

public class Cliente {
	
	public static void main(String[] args){
		Predio p = new Predio();
		Casa c = new Casa();
		
		ConstrutorPredio cP = new ConstrutorPredio(p);
		ConstrutorCasa cC = new ConstrutorCasa(c);
		
		Diretor d = new Diretor(cP);
				
		d.construir();
		System.out.println(cP.obterProduto());
		
		//Casa
		d.setConstr(cC);
		d.construir();
		System.out.println(cC.obterProduto());
	}

}
