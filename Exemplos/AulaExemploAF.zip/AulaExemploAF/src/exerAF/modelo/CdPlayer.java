package exerAF.modelo;

public class CdPlayer extends Som{

	public CdPlayer(){
		System.out.println("Construiu CdPlayer");
	}

}
