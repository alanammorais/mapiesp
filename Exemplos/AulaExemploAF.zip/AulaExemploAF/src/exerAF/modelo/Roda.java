package exerAF.modelo;

public class Roda {
	
	public Roda() {
		System.out.println("Construiu Roda");
	}

}
