package exerAF.modelo;

public class RodaSimples extends Roda{

	public RodaSimples(){
		System.out.println("Construiu  RodaSimples");
	}
}
