package exerAF.modelo;

public class CarroLuxoFactory extends CarroFactory{
	
	public CarroLuxoFactory() {}

	public Roda montarRoda() {
		return new RodaLigaLeve();
	}

	public Som montarSom() {
		return new Paredao();
	}

}
